/******************************************************************************
* revision v1.0
* File:   debug.h
* Author: lion037osx
* File:   DrawGraphics.h
 * Created on June 25, 2017, 2:35 PM
******************************************************************************/

#ifndef DRAWGRAPHICS_H
#define	DRAWGRAPHICS_H

#ifdef	__cplusplus
extern "C" {
#endif

void drawScreen(void);
//void buttonSelect(UINT8 select);
//void button(WORD color,UINT16 x_start_tmp,UINT16 x_end_tmp,UINT16 y_start_tmp,UINT16 y_end_tmp);
void init_buttons_draw(void);
void home_draw(void );
void draw_menu(int sel );
void draw_button_slider(void);


#ifdef	__cplusplus
}
#endif

#endif	/* DRAWGRAPHICS_H */

