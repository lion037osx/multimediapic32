/* 
 * File:   DrawLogo.h
 * Author: optimus
 *
 * Created on 14 de agosto de 2017, 23:52
 */

#ifndef DRAWLOGO_H
#define	DRAWLOGO_H

#ifdef	__cplusplus
extern "C" {
#endif

void showLogo(void);


#ifdef	__cplusplus
}
#endif

#endif	/* DRAWLOGO_H */

