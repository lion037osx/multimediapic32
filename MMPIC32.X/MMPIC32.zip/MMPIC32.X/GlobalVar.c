
#include "GlobalVar.h"
#include <GenericTypeDefs.h>

UINT16 flagSetConfig=0;
BYTE strGet[32];

