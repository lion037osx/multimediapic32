/* 
 * File:   inits.h
 * Author: optimus
 *
 * Created on 7 de agosto de 2017, 23:03
 */

#ifndef INITS_H
#define	INITS_H

#ifdef	__cplusplus
extern "C" {
#endif

void inits(void);

#ifdef	__cplusplus
}
#endif

#endif	/* INITS_H */

