/* 
 * File:   run.h
 * Author: optimus
 *
 * Created on 7 de agosto de 2017, 23:06
 */

#ifndef RUN_H
#define	RUN_H

#ifdef	__cplusplus
extern "C" {
#endif
    
void run(void);


#ifdef	__cplusplus
}
#endif

#endif	/* RUN_H */

