/* 
 * File:   GlobalVar.h
 * Author: optimus
 *
 * Created on 10 de agosto de 2017, 19:42
 */

#ifndef GLOBALVAR_H
#define	GLOBALVAR_H

#ifdef	__cplusplus
extern "C" {
#endif

//#include <stdbool.h>
    
//static int flagSetConfig=0;


#ifdef	__cplusplus
}
#endif

#endif	/* GLOBALVAR_H */

