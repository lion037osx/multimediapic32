/* 
 * File:   interrupts.h
 * Author: optimus
 *
 * Created on 8 de agosto de 2017, 01:24
 */

#ifndef INTERRUPTS_H
#define	INTERRUPTS_H

#ifdef	__cplusplus
extern "C" {
#endif

void ConfigInterrupts(void);


#ifdef	__cplusplus
}
#endif

#endif	/* INTERRUPTS_H */

