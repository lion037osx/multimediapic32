/***********************************************************************
 * File:   GOLFont.h
 * Author: lion037osx
 *
 * Update on 2 de agosto de 2017, 12:11
 ************************************************************************/

#ifndef GOLFONT_H
#define	GOLFONT_H

#ifdef	__cplusplus
extern "C" {
#endif


    
#ifdef	__cplusplus
}
#endif

#endif	/* GOLFONT_H */

